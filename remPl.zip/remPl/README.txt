Project Title : NFC-based Attendance System

Members : 

	Jatin Garg [2014csb1017]
	Snehil Ameta [2014csb35]
	Jasdeep Singh [2014csb1016]
	Shailendra [2014csb1032]

----------------------------------------------------------------

References :

	Android Tutorials at [ https://www.tutorialspoint.com/android/ ]
	Android's NFC Documentation at [ https://developer.android.com/reference/android/nfc/package-summary.html ]
	Google Images for Data Set

-----------------------------------------------------------------

Instructions for Running :

	1) Start server at a given ip address and connect your mobile to internet.
	2) Make sure that the ip address value in the app is same as server's ip address (check from ipconfig command)
	3) Run the app


-----------------------------------------------------------------